import React, { Component } from 'react'
class Welcome extends Component {

    render(){
        return <h1>Welcome  {this.props.name} l.a.s {this.props.hero}</h1>
    }
}
export default Welcome