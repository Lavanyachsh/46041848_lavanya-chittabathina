import React, { Component } from 'react'

 class UserGreeting extends Component {
     constructor(props){
         super(props)
         this.state={
             isLoggedIn: true
         }
     }
    render() {
       return this.state.isLoggedIn && <div>welcome</div>
       // return(
           // this.state.isLoggedIn?(
            //<div>wow..</div>
         //   ): (
            //<div>bad....</div>
      //  )
       // let message
        //if(this.state.isLoggedIn){
         //   message = <div>welcome naidu</div>
       // }
       // else {
          //  message= <div>welcome chowdary</div>
       // }
       // return <div>{message}</div>
        //if(this.state.isLoggedIn){
           // return(
              //  <div>
              //      welcome naidu
               // </div>
          //  )
       // }
       // else{
          //  return(
             //   <div>welcome puppy</div>
          //  )
      //  }
      //  return (
           // <div>
            //  <div>welcome guest</div> 
            //   <div>welcome lavanya</div>
           // </div>
       // )
    }
}

export default UserGreeting
