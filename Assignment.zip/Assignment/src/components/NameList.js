import React from 'react'

function NameList() {
    const names = ['lav','rao','mom']
    const nameList = names.map(name => <h2>{name}</h2>)
    const persons =[
     {
    id: 1,
    name:'lav',
    age:30,
    skill:'react'
    },
    {
        id: 3,
        name:'lava',
        age:3,
        skill:'react'
        },
        {
            id: 2,
            name:'lavanya',
            age:30,
            skill:'react'
            }
        ]
        const personList = persons.map(person => <h2>{person.name}. i am {person.age} years of old. i know{person.skill}</h2>)
    return <div>{personList}</div>
   // return (
       // <div>
           // {
             //   names.map(name => <h2>{name}</h2>)
           // }
          // <h2>{names[0]}</h2>
          //  <h2>{names[1]}</h2>
           // <h2>{names[2]}</h2>
      //  </div>
    //)
}

export default NameList
