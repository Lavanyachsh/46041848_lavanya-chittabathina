import React from 'react'
//function Greet()
//{
   // return<h1>hello lavs</h1>
//}
const Greet = (props) => {
    console.log(props)
return (
    <div>
<h1>hello {props.name}l.v.s {props.hero}</h1>
{props.children}
</div>
)
}
export default Greet